#import <React/RCTBridgeModule.h>

@interface ProductSdk5 : NSObject <RCTBridgeModule>

@end
