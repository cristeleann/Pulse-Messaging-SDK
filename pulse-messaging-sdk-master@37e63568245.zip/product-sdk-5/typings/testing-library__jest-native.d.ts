/* eslint-disable @typescript-eslint/no-explicit-any */

/// <reference types="jest" />

declare namespace jest {
  interface Matchers<R> {
    toBeDisabled(): R;
    toBeEnabled(): R;
    toBeEmpty(): R;
    toContainElement(element: HTMLElement | null): R;
    toHaveProp(prop: string, value?: any): R;
    toHaveTextContent(text: string | RegExp, options?: { normalizeWhitespace: boolean }): R;
    toHaveStyle(style: object[] | object): R;
  }
}
