#!/usr/bin/env bash

set -ex

# This script will rename the whole project, including known references/file
# names inside native code

BASE_NAME="react-native-sdk-template"
BASE_CLASS_NAME="ProductSdk5"
BASE_DESCRIPTION="React Native SDK Template"

PACKAGE_NAME=$1
PACKAGE_CLASS_NAME=$2
PACKAGE_DESCRIPTION=$3

if [ -z "$PACKAGE_DESCRIPTION" ]; then
  echo "Usage: ./scripts/rename [package-name] [PackageName] [Package description]"
  exit
fi

#
# Root/JS
#
sed -i "" "s/${BASE_NAME}/${PACKAGE_NAME}/g" "README.md"
sed -i "" "s/${BASE_CLASS_NAME}/${PACKAGE_CLASS_NAME}/g" "README.md"

sed -i "" "s/${BASE_NAME}/${PACKAGE_NAME}/g" "package.json"
sed -i "" "s/${BASE_CLASS_NAME}/${PACKAGE_CLASS_NAME}/g" "package.json"
sed -i "" "s/${BASE_DESCRIPTION}/${PACKAGE_DESCRIPTION}/g" "package.json"

#
# Android
#
LC_ALL=C find ./android -type f -name "${BASE_NAME}*" -exec sed -i "" "s/${BASE_NAME}/${PACKAGE_NAME}/g" {} +
LC_ALL=C find ./android -type f -name "${BASE_CLASS_NAME}*" -exec sed -i "" "s/${BASE_CLASS_NAME}/${PACKAGE_CLASS_NAME}/g" {} +

mv "android/src/main/java/com/reactlibrary/${BASE_CLASS_NAME}Module.java" \
  "android/src/main/java/com/reactlibrary/${PACKAGE_CLASS_NAME}Module.java"

mv "android/src/main/java/com/reactlibrary/${BASE_CLASS_NAME}Package.java" \
  "android/src/main/java/com/reactlibrary/${PACKAGE_CLASS_NAME}Package.java"

#
# iOS
#
sed -i "" "s/${BASE_NAME}/${PACKAGE_NAME}/g" "${BASE_NAME}.podspec"

mv "${BASE_NAME}.podspec" "${PACKAGE_NAME}.podspec"

LC_ALL=C find ./ios -type f -name "${BASE_NAME}*" -exec sed -i "" "s/${BASE_NAME}/${PACKAGE_NAME}/g" {} +
LC_ALL=C find ./ios -type f -name "${BASE_CLASS_NAME}*" -exec sed -i "" "s/${BASE_CLASS_NAME}/${PACKAGE_CLASS_NAME}/g" {} +

mv "ios/${BASE_CLASS_NAME}.xcodeproj" "ios/${PACKAGE_CLASS_NAME}.xcodeproj"
mv "ios/${BASE_CLASS_NAME}.xcworkspace" "ios/${PACKAGE_CLASS_NAME}.xcworkspace"
mv "ios/${BASE_CLASS_NAME}.h" "ios/${PACKAGE_CLASS_NAME}.h"
mv "ios/${BASE_CLASS_NAME}.m" "ios/${PACKAGE_CLASS_NAME}.m"

grep --exclude-dir .git --exclude-dir rename.sh -lRZ "${BASE_CLASS_NAME}" . | xargs -0 -l sed -i '' -e "s/${BASE_CLASS_NAME}/${PACKAGE_CLASS_NAME}/g"

echo "Successfully renamed the project!"
