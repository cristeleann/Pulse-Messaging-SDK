const NAMESPACE = 'ProductSdk5';

export const Landing = `${NAMESPACE}/Landing`;
