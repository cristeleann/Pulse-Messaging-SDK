export { default } from './SDKModule';
