import { Action } from 'redux';

import { Env } from '../../types/app';

export const SET_ENV = 'SDK/SET_ENV';

interface SetEnv extends Action {
  type: typeof SET_ENV;
  payload: Env;
}

export type SDKAction = SetEnv;

export const setEnv = (env: Env): SetEnv => ({
  type: SET_ENV,
  payload: env
});
