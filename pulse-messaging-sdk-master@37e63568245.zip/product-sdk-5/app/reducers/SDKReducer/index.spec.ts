import { Env } from '../../types/app';

import { setEnv } from './actions';
import SDKReducer, { initialState } from './index';

describe('SDKReducer', () => {
  it('should set env state when setEnv is dispatched', () => {
    const env: Env = {
      SDK_ENV: 'prod'
    };

    const output = SDKReducer(initialState, setEnv(env));

    expect(output).toEqual({
      ...initialState,
      env
    });
  });

  it('should not modify state when an unknown action is dispatched', () => {
    // @ts-ignore
    const output = SDKReducer(undefined, { type: 'UNKNOWN' });

    expect(output).toEqual(initialState);
  });
});
