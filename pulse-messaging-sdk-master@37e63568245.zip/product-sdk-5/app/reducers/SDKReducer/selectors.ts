import { RootState } from '../../store';
import { Env } from '../../types/app';

export const getEnv = (state: RootState): Env => state.SDK.env;
