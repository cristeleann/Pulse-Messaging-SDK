import { DeepReadonly } from 'utility-types';

import { Env } from '../../types/app';

import { SDKAction, SET_ENV } from './actions';

type SDKState = DeepReadonly<{
  env: Env;
}>;

export const initialState: SDKState = {
  env: {
    SDK_ENV: 'prod'
  }
};

const SDKReducer = (state: SDKState = initialState, action: SDKAction): SDKState => {
  switch (action.type) {
    case SET_ENV:
      return {
        ...state,
        env: action.payload
      };

    default:
      return state;
  }
};

export default SDKReducer;
