import store from '../../store';
import { Env } from '../../types/app';

import { getEnv } from './selectors';

describe('selectors', () => {
  const rootState = store.getState();

  it('should return env when calling getEnv', () => {
    const env: Env = {
      SDK_ENV: 'prod'
    };

    const output = getEnv({
      ...rootState,
      SDK: {
        ...rootState.SDK,
        env
      }
    });

    expect(output).toBe(env);
  });
});
