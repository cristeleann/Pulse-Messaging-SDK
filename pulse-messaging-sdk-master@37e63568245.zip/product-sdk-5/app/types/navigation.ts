import { NavigationScreenProp } from 'react-navigation';

export type StackNavigationProp<State = {}, Params = {}> = NavigationScreenProp<State, Params>;
