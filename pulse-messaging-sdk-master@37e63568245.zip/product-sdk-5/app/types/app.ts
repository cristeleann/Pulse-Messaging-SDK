export interface Env {
  SDK_ENV: 'dev' | 'uat' | 'prod';
}
