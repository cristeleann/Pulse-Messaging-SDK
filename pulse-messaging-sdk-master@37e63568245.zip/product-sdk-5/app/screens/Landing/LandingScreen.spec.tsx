import React from 'react';
import { render, RenderAPI } from 'react-native-testing-library';

import { stackNavigationMock } from '../../__mocks__/navigationMocks';

import LandingScreen from './LandingScreen';

const renderLandingScreen = (props = {}): RenderAPI =>
  render(
    <LandingScreen
      // @ts-ignore
      navigation={stackNavigationMock}
      {...props}
    />
  );

describe('LandingScreen', () => {
  it('should render as expected', () => {
    const { toJSON } = renderLandingScreen();

    expect(toJSON()).toMatchSnapshot();
  });
});
