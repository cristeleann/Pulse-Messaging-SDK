import React from 'react';

import * as bannerImages from '../../assets/images/banners';
import { StackNavigationProp } from '../../types/navigation';


import { Container, Banner } from './LandingScreenStyles';

import Messaging from './messaging/index';

// import Survey from './qualtrics/Survey';

interface Props {
  navigation: StackNavigationProp;
}

const LandingScreen: React.FC<Props> = () => {
  return (
    <Container>
      {/* <Survey 
        serviceUrl="https://prulife.syd1.qualtrics.com/API/v3/surveys/SV_3QuJobjETMfMX3v/sessions"
        apiToken="b9og4olxyE2ftQEweO5vmTI3F3Z1axLefckFzyM8"/>       */}
      <Messaging />
    </Container>
  );
};

export default LandingScreen;
