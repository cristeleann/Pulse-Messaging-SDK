import styled from 'styled-components/native';

import { lightGrey } from '../../assets/colors';

export const Container = styled.View`
  flex: 1;
  justify-content: center;
  background-color: ${lightGrey};
`;

export const Banner = styled.ImageBackground`
  justify-content: space-between;
  height: 178px;
  width: 100%;
  padding: 24px;
  resize-mode: cover;
`;
