import React, { useState, useEffect, version } from 'react';

import { 
    ActivityIndicator,
    Dimensions, 
    StyleSheet, 
    View, 
    TouchableHighlight,
    ScrollView
} from 'react-native';


import { DefaultTheme, Provider as PaperProvider, Headline, Checkbox, Button } from 'react-native-paper';

const { width, height } = Dimensions.get('screen');

const colors = {
    transparent: 'transparent',
    white: '#fff',
    lightGray: '#f0f0f0',
    gray: '#e0e1e2',
    darkGray: '#cbcbcb',
    darkerGray: '#646464',
    red: '#ed1b2e',
    black: '#232323',
    skyBlue: '#009cbd'
};

const styles = StyleSheet.create({
    fullHeight: {
        flex: 1,
        height: Dimensions.get("window").height
    },
    container: {
        flex: 1,
        justifyContent: "center"
    },
    horizontal: {
        flexDirection: "row",
        justifyContent: "space-around",
        padding: 10
    },
	wrapper: {
		flex: 1,
        padding: 20,
        marginTop: 100        
    }
});

const theme = {
    ...DefaultTheme,
    roundness: 2,
    colors: {
      ...DefaultTheme.colors,
      primary: colors.black,
      accent: colors.red,
    },
};


export default function Survey({apiToken, serviceUrl}) {

    const [isLoading, setIsLoading] = useState(false);
    const [surveyState, setSurveyState] = useState({
        sessionId: '',
        hasNext: true,
        questions: [],
        values: {}
    });


    const service = {
        next: (path, sessionId, data, cb) => {        
          setIsLoading(true);
          if (sessionId){
            path = path + '/' + sessionId;
          }
    
          var myHeaders = new Headers();
          myHeaders.append("X-API-TOKEN", apiToken);
          myHeaders.append("Content-Type", "application/json");
          
          var raw = JSON.stringify(data);
          
          var requestOptions = {
            method: 'POST',
            headers: myHeaders,
            body: raw,
            redirect: 'follow'
          };
          console.log(path, raw);
          fetch(path, requestOptions)
          .then((response) => response.json())
          .then((result) => {
            if(result && result.meta && result.result){
              result.success = true;
              result.message = '';
              result.sessionId = result.result.sessionId;
              console.log('SessionID', result.sessionId);
            }else{
              result.success = false;
              if(result && result.meta)
                  result.message = result.meta.httpStatus;
            }
            console.log(result);
            setIsLoading(false);
            cb(result);
          })
          .catch((error) => {
            cb({ success: false, message: '', result: error });
          });          
       
        }
    };    

    const handleSelection = (q, c) => (evt) => {
        var selected = surveyState.values.responses[q.questionId][c.choiceId].selected;
        if(!q.options.multiSelect){
            var responses = surveyState.values.responses[q.questionId];
            for(var i in responses){
                responses[i].selected = false;
            }
        }
        var choice = surveyState.values.responses[q.questionId][c.choiceId];
        choice.selected = !selected;
        setSurveyState({...surveyState}); 
    };

    const moveNext = (evt) => {
        service.next(serviceUrl, surveyState.sessionId, surveyState.values, (p)=>{
            processQuestions(p);
        });        
    };

    const cleanChars = (str) => {
        return str.split('&nbsp;').join(' ').split('<br>').join('\n');
    };

    const processQuestions = (p) => {
        if(p.success){
            if(p.result.done==false){
                var valueMap = {advance:true, responses:{}};
                for(var i=0;i<p.result.questions.length;i++){
                    var q = p.result.questions[i];
                    valueMap.responses[q.questionId] = {};
                    for(var j=0;j<q.choices.length;j++){
                        valueMap.responses[q.questionId][q.choices[j].choiceId] = {selected: false};
                    }
                }
                var s = {
                    sessionId: p.sessionId,
                    hasNext: true,
                    questions: p.result.questions,
                    values: valueMap 
                };
                console.log('NEW SurveyState', s, p);
                setSurveyState(s);
            }else{
                var s = {
                    sessionId: p.sessionId,
                    hasNext: false,
                    endMessage: p.result.done,
                    questions: [],
                    values: {} 
                };
                console.log('Done Survey State', s, p);
                setSurveyState(s);
            }
        }else{
            console.log(p);
        }
    };

    useEffect(() => {
        var subscribed = {
            status: true
        };

        service.next(serviceUrl, false, {
            "language": "EN"
          }, (p)=>{
            processQuestions(p);
        });

        return () => {
            subscribed.status = false;
        };
    },[]);            

    return (
        <PaperProvider theme={theme} key="qualtrics-survey">
        <ScrollView>
            {surveyState.hasNext && <View style={styles.wrapper}>
                {surveyState.questions.map((q, qIndex) => (
                    <View key={q.questionId}>
                        <Headline>{cleanChars(q.display)}</Headline>                    
                        {q.choices.map((c, cIndex)=>{
                            return <TouchableHighlight
                                key={q.questionId+'-'+c.choiceId}
                                underlayColor='#f0f0f0'
                                style={{ borderRadius: 20 }}
                                onPress={handleSelection(q,c)}> 
                                    <Checkbox.Item label={cleanChars(c.display)} status={surveyState.values.responses[q.questionId][c.choiceId].selected==true ? 'checked': 'unchecked'} />
                            </TouchableHighlight>;
                        })}                        
                    </View>
                ))}
                {isLoading && <ActivityIndicator />}
                {!isLoading && <Button mode="outlined" onPress={moveNext}>Next</Button>}
            </View>}
            {!surveyState.hasNext && <View style={styles.wrapper}>
                <Headline>{cleanChars(surveyState.endMessage)}</Headline>
            </View>}
        </ScrollView>
        </PaperProvider>
    );
}
