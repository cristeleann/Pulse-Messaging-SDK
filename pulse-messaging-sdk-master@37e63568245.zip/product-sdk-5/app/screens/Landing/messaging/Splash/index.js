import React from 'react';
import {
    View,
    Image
} from 'react-native';
import PulseWLogo from '../assets/PulseWLogo.png';

export default class Splash extends React.Component {
    render() {
        return <View style={{
            flexDirection: 'row',
            justifyContent: 'center',
            alignItems: 'center',
            backgroundColor: '#ed1b2e',
            height: '100%'
        }}>
            <Image source={PulseWLogo} style={{
                width: 1510 * .08,
                height: 628 * .08,
            }} />
        </View>
    }
}