import React from "react";
import styles from "./styles";
import {
  View,
  ScrollView,
  Text,
  Image,
  ImageBackground,
  TouchableOpacity,
} from "react-native";
import { Icon } from "react-native-elements";

import Gradient from "../assets/Gradient.png";
import PulseWLogo from "../assets/PulseWLogo.png";
import Profile from "../assets/Profile.png";

import MyHealth from "../assets/My_Health.png";
import MyCommunities from "../assets/My_Communities.png";
import MyContent from "../assets/My_Content.png";
import MyPolicies from "../assets/My_Policies.png";
import PRUShoppe from "../assets/PRU_Shoppe.png";


import ChatBoard from "../ChatBoard";

export default class Dashboard extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      loading: false,
      showApp: false,
      auth: null,
      token: props.tokenAccess,
      userId: props.userId
    };
  }



  componentDidMount() {

  }



  render() {
    let { loading, showApp, token, userId } = this.state;
    return (
      <View style={styles.container}>
        <ImageBackground source={Gradient} style={styles.header}>
          <Image source={PulseWLogo} style={styles.pulse} />
          <Image source={Profile} style={styles.profile} />
          <Icon name="bell" type="font-awesome" color="white" size={24} />
        </ImageBackground>
        <View style={styles.menus}>
          {[
            {
              src: MyHealth,
              h2: "Health",
            },
            {
              src: MyCommunities,
              h2: "Communities",
            },
            {
              src: MyContent,
              h2: "Content",
            },
            {
              src: MyPolicies,
              h2: "Policies",
            },
            {
              src: PRUShoppe,
              h1: "PRU",
              h2: "Shoppe",
            },
          ].map((m, idx) => (
            <View key={"menu-" + idx} style={styles.menu}>
              <Image source={m.src} style={styles.menuIcon} />
              <Text style={styles.menuH1}>{m.h1 || "My"}</Text>
              <Text numberOfLines={1} style={styles.menuH2}>
                {m.h2}
              </Text>
            </View>
          ))}
        </View>
        <ChatBoard 
            user={{
                username: userId,
                email: '',
                firstname: '',
                lastname: '',
                gender: '',
                birthDate: '',
                mobileNo: '',
                photo: '',
                agentRefCode: '',
                covidFlag: '',
                policyPulse: '',
                address: ''
            }}
            accessKey="na2K8aYNjRX+zsJ3V/phoQ=="
            serviceUrl="https://chat.gallium.space"        
        />
        <View style={styles.bottom}>
          <View style={styles.bottomMenu}>
            <Icon name="home" type="font-awesome" color="#ed1b2e" size={28} />
            <Text style={styles.bottomH1}>Home</Text>
          </View>
          <View style={styles.bottomMenu}>
            <Icon name="ios-heart" type="ionicon" color="#ed1b2e" size={28} />
            <Text style={styles.bottomH1}>Health</Text>
          </View>
          <View style={styles.bottomMenu}>
            <Icon name="ios-person" type="ionicon" color="#ed1b2e" size={28} />
            <Text style={styles.bottomH1}>Account</Text>
          </View>
        </View>
        {loading && <View style={styles.loading}></View>}
      </View>
    );
  }
}
