import { StyleSheet, Dimensions } from 'react-native';

export default StyleSheet.create({
    container: {
        position: 'relative',
        flexDirection: 'column',
        height: '100%'
    },
    loading: {
        position: 'absolute',
        backgroundColor: 'rgba(255, 255, 255, 0.6)',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        zIndex: 4
    },
    header: {
        resizeMode: "cover",
        flexDirection: 'row',
        alignItems: 'center',
        height: 60,
        paddingHorizontal: 15
    },
    pulse: {
        width: 1510 * .05,
        height: 628 * .05,
        marginRight: 'auto'
    },
    profile: {
        backgroundColor: '#fff',
        width: 40,
        height: 40,
        borderRadius: 40,
        marginRight: 15
    },
    menus: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        backgroundColor: '#fff',
        paddingVertical: 15
    },
    menu: {
        flex: 1,
        flexDirection: 'column',
        alignItems: 'center',
        width: 50
    },
    menuIcon: {
        width: 40,
        height: 40,
        borderRadius: 40,
        marginBottom: 5
    },
    menuH1: {
        color: '#232323',
        fontSize: 11
    },
    menuH2: {
        color: '#646464',
        fontSize: 10
    },
    content: {
        flex: 1,
        backgroundColor: '#fff'
    },
    tile: {
        flexDirection: 'column',
        justifyContent: 'flex-end',
        height: 140,
        padding: 10,
        margin: 10,
        borderRadius: 5,
        overflow: 'hidden'
    },
    tileH1: {
        color: '#fff',
        fontSize: 14,
        fontWeight: 'bold'
    },
    line: {
        backgroundColor: '#ed1b2e',
        width: 50,
        height: 3,
        marginTop: 5,
        marginBottom: 10
    },
    tileP: {
        color: '#fff',
        fontSize: 11
    },
    bottom: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        backgroundColor: '#fff',
        paddingTop: 10,
        paddingHorizontal: 30,
        paddingBottom: 15
    },
    bottomMenu: {
        flexDirection: 'column',
        alignItems: 'center'
    },
    bottomH1: {
        color: '#646464',
        fontSize: 13
    },
    wrapper: {
		flex: 1,
		padding: 20
    },
    lead: {
		flexDirection: 'row',
		padding: 10
    },
    info: {
		flex: 1,
		marginLeft: 20
	},
});