import React, { useState, useEffect, version } from 'react';

import { 
    ActivityIndicator,
    Dimensions, 
    StyleSheet, 
    KeyboardAvoidingView,
    View, 
    Text,
    TouchableHighlight,
    ScrollView,
    FlatList,
    Image,
    TouchableOpacity,
    TextInput,
    RefreshControl
} from 'react-native';

import { Provider, Searchbar} from 'react-native-paper';
import { GiftedChat, Send } from 'react-native-gifted-chat';
import { Avatar } from 'react-native-paper';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { WebView } from 'react-native-webview';
import { weekdaysMin } from 'moment-timezone';

import sendButton from '../assets/send-button.png';
import pulseIcon from '../assets/pulse-chat.png';
import telegramIcon from '../assets/telegram-chat.png';
import telegramLogo from '../assets/telegram-logo.png';


/**
 * USAGE
 *         
 <ChatBoard 
    user={{
        username: 'bin.signup@gmail.com',
        email: 'lexluger.a.basilio@prulifeuk.com',
        firstname: 'Lex Luger',
        lastname: 'Basilio',
        gender: 'M',
        birthDate: '11/17/1993',
        mobileNo: '',
        photo: '',
        agentRefCode: '',
        covidFlag: '',
        policyPulse: '',
        address: ''
    }}
    accessKey="na2K8aYNjRX+zsJ3V/phoQ=="
    serviceUrl="http://128.199.218.1"        
/>
 */

const { width, height } = Dimensions.get('screen');

const styles = StyleSheet.create({
    chatFabMenu: {
        marginTop: 75
    },
    fullHeight: {
        flex: 1,
        height: Dimensions.get("window").height
    },
    container: {
        flex: 1,
        justifyContent: "center"
    },
    horizontal: {
        flexDirection: "row",
        justifyContent: "space-around",
        padding: 10
    }
});

const colors = {
    transparent: 'transparent',
    white: '#fff',
    lightGray: '#f0f0f0',
    gray: '#e0e1e2',
    darkGray: '#cbcbcb',
    darkerGray: '#646464',
    red: '#ed1b2e',
    black: '#232323',
    skyBlue: '#009cbd'
}

const stylesChatlist =  StyleSheet.create({
	title: {
		color: colors.black,
		fontSize: 24,
		fontWeight: 'bold',
		marginBottom: 20
	},
	progressContainer: {
		padding: 20
	},
	progressLabel: {
		flexDirection: 'row',
		alignItems: 'center',
		marginBottom: 10
	},
	progressText: {
		flex: 1,
		color: colors.black,
		fontSize: 14,
		fontWeight: 'bold',
		textAlign: 'center'
	},
	progressBar: {
		flexDirection: 'row',
		backgroundColor: colors.gray,
		width: '100%',
		height: 16,
		borderRadius: 16
	},
	bar: {
		backgroundColor: colors.red,
		width: '40%',
		borderRadius: 16,
		shadowColor: '#000',
		shadowOffset: {
			width: 0,
			height: 3
		},
		shadowOpacity: 0.27,
		shadowRadius: 4.65,
		elevation: 6
	},
	container: {
		flex: 1,
		backgroundColor: colors.white,
		borderTopLeftRadius: 15,
		borderTopRightRadius: 15
	},
	wrapper: {
		flex: 1,
		padding: 20
	},
	lead: {
		flexDirection: 'row',
		padding: 10
	},
	status: {
		position: 'absolute',
		top: 20,
		left: 0,
		paddingVertical: 4,
		//paddingHorizontal: 8,
		borderRadius: 6,
		shadowColor: '#000',
		shadowOffset: {
			width: 0,
			height: 3
		},
		shadowOpacity: 0.27,
		shadowRadius: 4.65,
		zIndex: 6,
		elevation: 6
	},
	statusText: {
		color: colors.white,
		fontSize: 12,
		fontWeight: 'bold'
	},
	photo: {
		backgroundColor: colors.gray,
		width: 100,
		height: 100,
		borderRadius: 15,
		overflow: 'hidden',
		shadowColor: '#000',
		shadowOffset: {
			width: 0,
			height: 3
		},
		shadowOpacity: 0.27,
		shadowRadius: 4.65,
		zIndex: 6,
		elevation: 6
	},
	info: {
		flex: 1,
		marginLeft: 20
    },
    infoNew: {
        flexDirection: 'row',
    },
	h1: {
		color: colors.black,
		fontSize: 16,
		fontWeight: 'bold',
		marginBottom: 5
    },
    chatLabelText:{
        color: colors.black,
        fontSize: 16,
        fontWeight: 'bold'
    },
	p: {
		color: colors.darkerGray,
		fontSize: 14
	},
	remarks: {
		color: colors.black,
		fontSize: 13
	},
	tabs: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		borderTopWidth: 1,
		borderTopColor: colors.gray,
		borderBottomWidth: 1,
		borderBottomColor: colors.gray,
		paddingHorizontal: 5
	},
	tab: {
		flexDirection: 'row',
		justifyContent: 'center',
		alignItems: 'center',
		height: 40,
		paddingHorizontal: 10
	},
	tabText: {
		fontSize: 14,
		fontWeight: 'bold'
	},
	hRule: {
		marginTop: 40,
		marginBottom: 40,
		borderBottomColor: 'black',
		borderBottomWidth: 1
    },
    avatarItem: {
        marginHorizontal: 5,
        backgroundColor: '#ed1b2e'
    },
    avatarItemT: {
        marginHorizontal: 5,
        backgroundColor: '#0088cc'
    },
    back_button: {
        fontSize: 28,
        color: 'black',
        marginLeft:5
    },
    headerChatText:{
        marginTop: 5,
        marginLeft: 5
    },
    GiftedChat:{
        flex:1
    },
    chatLabel:{
        marginHorizontal:4,
        justifyContent: 'center'
    },
    menuContainer: {
        justifyContent: 'center',
        flexDirection: 'row',
        backgroundColor: '#ffffff'
    },
    menu_buttonstyle: {
        backgroundColor:'#fff',
        height: 40,
        alignItems: 'center'
    },
    menu_textstyle: {
        color: '#000',
        fontSize: 15,
        paddingLeft: 15,
        paddingRight: 20
    },
    sendContainer: {
        justifyContent: 'center'
    },
    chatIconContainer:{
        marginHorizontal:4,
        justifyContent: 'center'
    },
});

const stylesTelegram =  StyleSheet.create({
    mainBody: {
      flex: 1,
      justifyContent: 'center',
      backgroundColor: '#ffffff',
    },
    SectionStyle: {
      flexDirection: 'row',
      height: 40,
      marginTop: 20,
      marginLeft: 35,
      marginRight: 35,
      margin: 10,
    },
    buttonStyle: {
      backgroundColor: '#ed1b2e',
      borderWidth: 0,
      color: '#FFFFFF',
      borderColor: '#ed1b2e',
      height: 40,
      alignItems: 'center',
      borderRadius: 30,
      marginLeft: 35,
      marginRight: 35,
      marginTop: 20,
      marginBottom: 20,
    },
    buttonTextStyle: {
      color: '#FFFFFF',
      paddingVertical: 10,
      fontSize: 16,
    },
    inputStyle: {
      flex: 1,
      color: 'black',
      paddingLeft: 15,
      paddingRight: 15,
      borderWidth: 1,
      borderRadius: 30,
      borderColor: 'black'
    }
  });

// var PushNotificationIOS = require('react-native-push-notification');

// PushNotificationIOS.configure({

//     // (optional) Called when Token is generated (iOS and Android)
//     onRegister: function(token) {
//         console.log( 'TOKEN:', token );
//     },
//     // (required) Called when a remote or local notification is opened or received
//     onNotification: function(notification) {
//         console.log( 'NOTIFICATION:', notification );

//         // process the notification

//         // required on iOS only (see fetchCompletionHandler docs: https://facebook.github.io/react-native/docs/pushnotificationios.html)
//         notification.finish(PushNotificationIOS.FetchResult.NoData);
//     },
//     // IOS ONLY (optional): default: all - Permissions to register.
//     permissions: {
//         alert: true,
//         badge: true,
//         sound: true
//     },
//     // Should the initial notification be popped automatically
//     // default: true
//     popInitialNotification: true,
//     /**
//       * (optional) default: true
//       * - Specified if permissions (ios) and token (android and ios) will requested or not,
//       * - if not, you must call PushNotificationsHandler.requestPermissions() later
//       */
//     requestPermissions: true,
// });

renderSend = (props) => {
    return (
      <Send
        {...props}
        containerStyle={styles.sendContainer}
      >
        <Image source={sendButton} style={{
                marginRight: 10,
                width: 300 * .08,
                height: 300 * .08,
            }}/>
        </Send>
    );
  }

export default function ChatBoard({user, accessKey, serviceUrl}) {

    var service = {
        authResult: {},
        getUser: () => {
            return service.authResult.result;
        },
        getDeviceID: () => {
            return '';
        },
        authenticate: (userName, cb) => {
            service.post(
                '/login',
                {
                  username: userName,
                  password: accessKey,
                  pulseUser: user
                },
                (p) => {
              
                  if (p.success) {
                    service.authResult = p;
                    ChatBoard.chat.firstname = p.result.firstname;
                    ChatBoard.chat.lastname = p.result.lastname;
                    ChatBoard.chat.mobileNo = p.result.mobileNo;
                  }
                  cb(p);
                }
            );  
        },
        upload: (path, data, files, cb) => {
          let formData = new FormData();
          let json = JSON.stringify(data);
          formData.append('data', json);
          for (var i = 0; i < files.length; i++) {
            var file = files[i];
            formData.append(file.field, {
              name: file.name,
              type: file.type,
              uri: file.uri
            });
          }
          if (service.getUser() && service.getUser().token)
            formData.append('token', service.getUser().token);
          if (service.getUser() && service.getUser().clientid)
            formData.append('clientid', service.getUser().clientid);
          if (service.getDeviceID()) formData.append('deviceid', service.getDeviceID());
    
          let headers = {
            'cache-control': 'no-cache',
            'no-store': 'true',
            'must-revalidate': 'true',
            'pre-check': '0',
            'post-check': '0',
            'max-age': '0',
            's-maxage': '0',
            Expires: '0',
            Pragma: 'no-cache',
            'content-type': 'multipart/form-data'
          };
    
          let payload = {
            method: 'POST',
            headers: headers,
            body: formData
          };
    
          fetch(serviceUrl + path, payload)
            .then((response) => response.json())
            .then((result) => {
              cb(result);
            })
            .catch((error) => {
              cb({ success: false, message: '', result: error });
            });
        },
        post: (path, data, cb) => {
          let formData = new FormData();
          let json = JSON.stringify(data);
          formData.append('data', json);
          if (service.getUser() && service.getUser().token)
            formData.append('token', service.getUser().token);
          if (service.getUser() && service.getUser().clientid)
            formData.append('clientid', service.getUser().clientid);
          if (service.getDeviceID()) formData.append('deviceid', service.getDeviceID());
    
          let headers = {
            'cache-control': 'no-cache',
            'no-store': 'true',
            'must-revalidate': 'true',
            'pre-check': '0',
            'post-check': '0',
            'max-age': '0',
            's-maxage': '0',
            Expires: '0',
            Pragma: 'no-cache'
          };
    
          let payload = {
            method: 'POST',
            headers: headers,
            body: formData
          };
    
            if(path === '/telegram'){
                serviceUrl = "http://159.65.9.187:10007";
                path = "/api"
            } else {
                serviceUrl="https://chat.gallium.space";
            }

          fetch(serviceUrl + path, payload)
            .then((response) => response.json())
            .then((result) => {
              cb(result);
            })
            .catch((error) => {
              cb({ success: false, message: '', result: error });
            });
        }
    };

    const [userName, setUserName] = useState(user.username);
    const [selectedUser, setSelectedUser] = useState({
        _id: '',
        name: ''
    });

    const [selectedTelegramUser, setSelectedTelegramUser] = useState({
        _id: '',
        name: ''
    });

    const [searchQuery, setSearchQuery] = useState('');
    const [messages, setMessages] = useState([]);
    const [screen, setScreen] = useState('conversations');
    const [pulse, setPulseChat] = useState('pulsechat');
    const [conversations, setConversations] = useState([]);

    const getMessages = () => {
        if(ChatBoard.chat.chatId){
            console.log('Getting Messages:', ChatBoard.chat.chatId);
            ChatBoard.service.post('/bean/search/pulseMessage',{chatId:ChatBoard.chat.chatId},(pm)=>{
                console.log(pm);
                if(pm.success && pm.result.length>0){
                    var msgs = [];
                    for(var i=0;i<pm.result.length;i++){
                        var m = pm.result[i];
                        msgs.push({
                            ...m,
                            _id: m.id,
                            createdAt: new Date(m.createdDate),
                            user:{
                                _id: m.userId,
                                name: m.name,
                                avatar: m.avatar
                            }
                        });
                    }
                    console.log(msgs);
                    setMessages(msgs);
                }
            })
        }else{
            setMessages([]);
        }
    };

    const getConversations = () => {
        console.log('Getting Conversations:', user.username);
        ChatBoard.service.post('/bean/query/my-pulse-chats',{userId:user.username},(pm)=>{
            console.log(pm);
            if(pm.success && pm.result.length>0){
                setConversations(pm.result);
            }
        })
    };

    const monitorChat = (chatId) => {
        if(ChatBoard.chat.socket && ChatBoard.socket.chatId!=chatId){
            ChatBoard.socket.close();
        }else if(ChatBoard.chat.socket && ChatBoard.socket.chatId==chatId){
            return;
        }
        ChatBoard.socket = new WebSocket('ws://159.65.9.187:10006');
        ChatBoard.socket.onopen = ()=>{
            ChatBoard.socket.send(JSON.stringify({
                action: 'subscribe',
                docId: chatId
            }));
        };
        ChatBoard.socket.onmessage = (evt) => {
            console.log('ON MESSAGE', evt, evt.data);
            try{
                var data = JSON.parse(evt.data);
                if(data){
                    if(data.action=='create' && data.beanType=='pulseMessage'){
                        if(data.id == ChatBoard.chat.chatId){
                            getMessages();
                        }
                    }
                }
            }catch(e){
                console.log(e);
            }
        };        
    };

    const [mobileNo, setMobileNo] = useState([]);

    const [userId, setUserId] = useState([]);

    const getUserId = () => {
        console.log('Getting User ID:', user.username);
        ChatBoard.service.post('/bean/search/user',{username:user.username},(pm)=>{
            if(pm.success){
                for(var i = 0; i < pm.result.length ; i++){
                    if(pm.result[i].id == ''){
                        console.log("User ID not available");
                        return "";
                    } else {
                        console.log("Retrieved UserId:",pm.result[i].id);
                        setUserId(pm.result[i].id);
                    }
                }
            } else {
                console.log("User ID not found.");
                return "";
            }
        })
    };

    const postSetMobileNo = (mobileNo) => {
        setIsLoading(true);
        console.log("Enter mobile no for:", user.username);
        ChatBoard.service.post('/bean/update/user',{
            "_type":"leads:user",
            "mobileNo": mobileNo +"",
            "id": userId +"" 
        },(pm)=>{
            console.log("postSetMobileNo",pm);
            if(pm.success){
                console.log("User Mobile No Updated, Telegram Logging In");
                setTelegramMobileNo(mobileNo);
                getSessionToTelegram(mobileNo);
            } else {
                console.log("update failed");
            }
        });
    };

    const getMobileNo = (cb) => {
        console.log('Getting Mobile No:', user.username);
        ChatBoard.service.post('/bean/search/user',{username:user.username},(pm)=>{
            if(pm.success){
                for(var i = 0; i < pm.result.length ; i++){
                    if(pm.result[i].mobileNo == ''){
                        console.log("mobileNo is empty");
                        cb('');
                    } else {
                        console.log("Retrieved mobileNo:",pm.result[i].mobileNo);
                        cb(pm.result[i].mobileNo);
                    }
                }
            } else {
                console.log("User not found.");
                cb("");
            }
        })
    };

    /*--Telegram--*/
    
    const [registertelegram, setRegisterTelegram] = useState('registertelegram');
    const [entercode, setCode] = useState('entercode');
    const [conversationstelegram, setConversationsTelegram] = useState('conversationstelegram');
    const [isLoading, setIsLoading] = useState(true);

    const [telegramMobileNo, setTelegramMobileNo] = useState([]);
    const [telegramConversations, setTelegramConversations] = useState([]);
    const [telegramMessages, setTelegramMessages] = useState([]);
    const [telegramCurrentChatId, setTelegramCurrentChatId] = useState([]);
    const [telegramSession, setTelegramSession] = useState([]);
    const [telegramCode, setTelegramCode] = useState([]);
    const [telegramCurrentAccessHash, setTelegramCurrentAccessHash] = useState([]);


    const getSessionToTelegram = (mobileNo) => {
        console.log('Check Session:',mobileNo);
        service.post('/telegram',{
            "t": mobileNo,
            "m": "getSession",
            "a": []
        },(vc)=>{
            console.log("vc",vc);
            if(vc.success){
                if(vc.hasSession === 'false'){
                    console.log("no session")
                    postConnectToTelegram(mobileNo);
                }
                else{
                    console.log("Has Telegram Session")
                    postDestroySessionTelegram(mobileNo);
                }
            } else {
                console.log("making new session")
                postConnectToTelegram(mobileNo);
            }
        });
    };

    const postDestroySessionTelegram = (mobileNo) => {
        console.log('Destroying Session for:',mobileNo);
        service.post('/telegram',{
            "t": mobileNo,
            "m": "destroy",
            "a": []
        },(vc)=>{
            console.log("checking destroy",vc);
            if(vc.success&&vc.message == "client.removed"){
                console.log("Destroyed Session", vc)
                postConnectToTelegram();
            }else{
                console.log("Not able to destroy session", vc)
            }
        });
    };
    
    const postConnectToTelegram = (telegramMobileNo) => {
        console.log('Connecting:',telegramMobileNo);
        service.post('/telegram',{
            "t": telegramMobileNo,
            "m": "connect",
            "a": []
        },(vc)=>{
            console.log("vc",vc);
            if(vc.success){
                console.log(vc.result);
                if(vc.result.success){
                    console.log("No Session",vc);
                    setScreen('entercode');
                }
            } else {
                console.log("Connect Again",vc);
                postConnectToTelegram(mobileNo);
                setIsLoading(false);
            }
        });
    };

    const postSetLoginCodeTelegram = (evt) => {
        service.post('/telegram',{
            "t":telegramMobileNo,
            "m": "setCode",
            "a":[telegramCode]
        },(vc)=>{
            console.log(vc);
            if(vc.success&&vc.message=='code.active'){
                console.log("Correct Code", vc)
                getTelegramConverstations();
                getConversations();
            } else {
                console.log("Incorrect Code", vc);
                setScreen('entercode');
            }
        });
    };

    const getTelegramConverstations = (mobileNo) =>{
        console.log('getting telegram conversations', mobileNo);
        service.post('/telegram',{
            "t": mobileNo,
            "m": "getChats",
            "a": []
        },(vc)=>{
            console.log("show chat here",vc);
            if(vc.success && vc.message == 'got.chats'){
                console.log("Got Chats", vc)
                var a = [];
                for(var i=0;i<vc.result.length;i++){
                    var r = vc.result[i]._user;
                    var o = {
                        _user:{
                            _id: r.id,
                            access_hash: r.access_hash,
                            name: r.first_name + ' ' + r.last_name
                        },
                        "userId": r.id,
                        "access_hash": r.access_hash,
                        "first_name": r.first_name,
                        "last_name": r.last_name
                    }
                    if(r.self){
                        setSelectedTelegramUser({
                            _id: r.id,
                            name:  r.first_name + ' ' + r.last_name
                        });
                    }
                    a.push(o);
                }
                console.log("conversations here", a);
                setTelegramConversations(a);
                setIsLoading(false);
            } else {
                console.log("Client is not connected", vc);
                setIsLoading(false);
                setScreen('registertelegram');
            }
        });
    };
    
    const getTelegramMessage =(chatId,accessHash) =>{
        console.log("chatId",chatId);
        console.log("accessHash",accessHash);
        service.post('/telegram',{
            "t":telegramMobileNo,
            "m": "getChat",
            "a":[chatId,accessHash]
        },(vc)=>{
            console.log(vc);
            if(vc.success){
                var a = [];
                console.log("check raw message here",vc.result.messages);
                for(var i = 0; i < vc.result.messages.length ; i++){
                    var r = vc.result.messages[i];
                    var o = {
                        _id: r.id,
                        chatId: r.id,
                        createdAt: new Date(r.date),
                        user:{
                            _id: r.from_id,
                            name: r.from_id+"",
                            avatar: ""
                        },
                        "text": r.message,
                        "userId": r.from_id,
                        "name": r.from_id+"",
                        "avatar": "",
                        "image": "",
                        "video": "",
                        "audio": "",
                        "system": false,
                        "sent": false,
                        "received": false,
                        "pending": false
                    }
                    a.push(o);   
                }
                setTelegramMessages(a);
                console.log("check message here",a);
            }
        });
    };

    const postSendMessage = (message) =>{
        console.log(telegramMobileNo);
        console.log(telegramCurrentChatId);
        console.log(telegramCurrentAccessHash);
        console.log(message)
        service.post('/telegram',{
            "t":telegramMobileNo,
            "m": "sendMessage",
            "a":[telegramCurrentChatId,telegramCurrentAccessHash, message]
        },(vc)=>{
            console.log(vc);
            if(vc.success){
                getTelegramMessage(telegramCurrentChatId,telegramCurrentAccessHash);
            }
        });
    };
    /*--End Telegram--*/

    useEffect(() => {
        var subscribed = {
          status: true
        };
        let messageTimer, conversationTimer;
        service.authenticate((p)=>{
            if(subscribed.status && p.success){
                refreshConversations();

                messageTimer = setInterval(()=>{
                    refreshMessages();
                },2000);
                
                conversationTimer = setInterval(()=>{
                    refreshConversations();
                },5000);
            }
        });

        if(!ChatBoard.chat){
            ChatBoard.chat = {
                username: ''
            };
            ChatBoard.service = service;
        }

        ChatBoard.chat.username = userName; 
        console.log('loggin in as ', userName);
        ChatBoard.service.authenticate(userName, p=>{
            setSelectedUser({
                _id: p.result.username,
                name: p.result.firstname + ' ' + p.result.lastname,
                mobileNo: p.result.mobileNo
            });
            console.log(p);
            getUserId();
            
            getMobileNo((mobile)=>{
                if(mobile==undefined || mobile=='' || mobile.trim()==''){
                    console.log('Register Request to Telegram');
                    setScreen('registertelegram');
                } else {
                    setMobileNo(mobile);
                    setTelegramMobileNo(mobile);
                    getTelegramConverstations(mobile);
                    getConversations();
                }
               
            });
        });

        return () => {
          subscribed.status = false;
        };
    },[]);

    pulsePush = (message) =>{
        // PushNotificationIOS.presentLocalNotification({
        //     alertTitle:"Notification",
        //     alertBody: "Welcome to Pulse Chat"
        // })

    }
    
    telegramPush = (message) =>{
        // PushNotificationIOS.presentLocalNotification({
        //     alertTitle:"Notification",
        //     alertBody: "Logged In to Pulse Telegram"
        // })
    }

    const wait = (timeout) => {
        return new Promise(resolve => {
          setTimeout(resolve, timeout);
        });
      }
      

    const [refreshing, setRefreshing] = React.useState(false);
      
    const onRefresh = React.useCallback(() => {
        setRefreshing(true);

        wait(2000).then(() => setRefreshing(false));
    }, []);

    return (<Provider>

        <View style={stylesChatlist.menuContainer}>
            <Ionicons.Button
                style={stylesChatlist.menu_buttonstyle}
                onPress={() => {
                    getConversations();
                    getTelegramConverstations();
                    setScreen('conversations');
                }}
            >
                <Text style={stylesChatlist.menu_textstyle}>All</Text>
            </Ionicons.Button>
            <Ionicons.Button
                style={stylesChatlist.menu_buttonstyle}
                onPress={() => {
                    getConversations();
                    setScreen('pulsechat');
                    pulsePush();
                }}
            >
                <Text style={stylesChatlist.menu_textstyle}>Pulse Chat</Text>
            </Ionicons.Button>
            <Ionicons.Button
                style={stylesChatlist.menu_buttonstyle}
                onPress={() => {
                    getTelegramConverstations(); 
                    setScreen('conversationstelegram');
                    telegramPush();
                }}
            >
                <Text style={stylesChatlist.menu_textstyle}>Telegram</Text>
            </Ionicons.Button>
        </View>

        {screen == 'conversations' &&
        <ScrollView 
            refreshControl={
            <RefreshControl 
                refreshing={refreshing} 
                onRefresh={() => {
                    onRefresh("Refreshing");
                    getConversations();
                    getTelegramConverstations();
                }}
            />
        }> 
            <Searchbar
                placeholder="Search Email"
                onChangeText={(query)=>{
                    setSearchQuery(query);
                }}
                onIconPress={()=>{
                    ChatBoard.service.post('/bean/query/search-pulse-user',{email: searchQuery.toLowerCase()},(p)=>{
                        console.log('Search pulse User', p);
                        if(p.success && p.result.length>0 && p.result[0].hasOwnProperty('chatId')){
                            ChatBoard.chat.chatId = p.result[0].chatId;
                            ChatBoard.chat.target = searchQuery.toLowerCase().trim();
                            monitorChat(ChatBoard.chat.chatId);
                        }else{
                            ChatBoard.chat.chatId = undefined;
                            ChatBoard.chat.target = searchQuery.toLowerCase().trim();                        
                        }
                        setScreen('chat');
                        getMessages();
                    });
                }}
                value={searchQuery}
            />
            <View style={stylesChatlist.wrapper}>
                {conversations.map((l, index) => (
                <TouchableHighlight
                    underlayColor='#f0f0f0'
                    style={{ borderRadius: 20 }}
                    onPress={() =>{
                        ChatBoard.chat.chatId = l.chatId
                        setScreen('chat');
                        getMessages();
                        monitorChat(l.chatId);
                    }
                    }>
                    <View style={stylesChatlist.lead}>
                        <View style={stylesChatlist.infoNew}>
                            {l.members.map((m, index) => {
                                if(m.userId !== user.username){
                                    return <Avatar.Text size={48} label={m.userId.substring(0,1).toUpperCase()} style={stylesChatlist.avatarItem} />
                                }
                            })}
                            <View style={stylesChatlist.chatLabel}>
                                {l.members.map((m2, index) => {
                                    if(m2.userId !== user.username){
                                        return <Text  style={stylesChatlist.chatLabelText}>{m2.name.split(' ')[0]}</Text>
                                    }
                                })}
                                
                            </View>
                        </View>
                        <View style={stylesChatlist.chatIconContainer}>
                            <Image source={pulseIcon}/>
                        </View>                        
                    </View>
                </TouchableHighlight>))}

                {telegramConversations.map((l, index) => (
                <TouchableHighlight
                    underlayColor='#f0f0f0'
                    style={{ borderRadius: 20 }}
                    onPress={() =>{
                        setTelegramCurrentChatId(l.userId);
                        setTelegramCurrentAccessHash(l.access_hash);
                        setScreen('telegram-chat');
                        getTelegramMessage(l.userId,l.access_hash);

                    }
                    }>
                    <View style={stylesChatlist.lead}>
                        <View style={stylesChatlist.infoNew}>
                            <Avatar.Text size={48} label={l.first_name.substring(0,1).toUpperCase()} style={stylesChatlist.avatarItemT} />
                            <View style={stylesChatlist.chatLabel}>
                                { l.last_name === undefined && 
                                    <View style={stylesChatlist.infoNew}>
                                        <Text  style={stylesChatlist.chatLabelText}>{l.first_name}</Text>
                                    </View>
                                }
                                { l.last_name != undefined && 
                                    <View style={stylesChatlist.infoNew}>
                                        <Text  style={stylesChatlist.chatLabelText}>{l.first_name + " " +  l.last_name}</Text>
                                    </View>
                                }   
                            </View>
                            <View style={stylesChatlist.chatIconContainer}>
                                <Image source={telegramIcon}/>
                            </View>
                        </View>
                    </View>
                </TouchableHighlight>))}
            </View>
            {(isLoading && screen=='conversations') &&  <View style={[styles.container, styles.horizontal]}>
                <ActivityIndicator />
            </View>}
        </ScrollView>}

        {screen == 'pulsechat' &&
        <ScrollView 
            refreshControl={
            <RefreshControl 
                refreshing={refreshing} 
                onRefresh={() => {
                    onRefresh("Refreshing");
                    getConversations();
                }}
            />
        }> 
            <Searchbar
                placeholder="Search Email"
                onChangeText={(query)=>{
                    setSearchQuery(query);
                }}
                onIconPress={()=>{
                    ChatBoard.service.post('/bean/query/search-pulse-user',{email: searchQuery.toLowerCase()},(p)=>{
                        console.log('Search pulse User', p);
                        if(p.success && p.result.length>0 && p.result[0].hasOwnProperty('chatId')){
                            ChatBoard.chat.chatId = p.result[0].chatId;
                            ChatBoard.chat.target = searchQuery.toLowerCase().trim();
                            monitorChat(ChatBoard.chat.chatId);
                        }else{
                            ChatBoard.chat.chatId = undefined;
                            ChatBoard.chat.target = searchQuery.toLowerCase().trim();                        
                        }
                        setScreen('chat');
                        getMessages();
                    });
                }}
                value={searchQuery}
            />
            <View style={stylesChatlist.wrapper}>
                {conversations.map((l, index) => (
                <TouchableHighlight
                    underlayColor='#f0f0f0'
                    style={{ borderRadius: 20 }}
                    onPress={() =>{
                        ChatBoard.chat.chatId = l.chatId
                        setScreen('chat');
                        getMessages();
                        monitorChat(l.chatId);
                    }
                    }>
                    <View style={stylesChatlist.lead}>
                        <View style={stylesChatlist.infoNew}>
                            {l.members.map((m, index) => {
                                console.log(m);
                                if(m.userId !== user.username){
                                    return <Avatar.Text size={48} label={m.userId.substring(0,1).toUpperCase()} style={stylesChatlist.avatarItem} />
                                }
                            })}
                            <View style={stylesChatlist.chatLabel}>
                                {l.members.map((m2, index) => {
                                    if(m2.userId !== user.username){
                                        return <Text  style={stylesChatlist.chatLabelText}>{m2.name.split(' ')[0]}</Text>
                                    }
                                })}
                            </View>
                            <View style={stylesChatlist.chatIconContainer}>
                                <Image source={pulseIcon}/>
                            </View>
                        </View>
                    </View>
                </TouchableHighlight>))}
            </View>
            {(isLoading && screen=='pulsechat') &&  <View style={[styles.container, styles.horizontal]}>
                <ActivityIndicator />
            </View>}            
        </ScrollView>}

        {screen == 'registertelegram' && 
        <ScrollView>
            <View style={stylesTelegram.mainBody}>
                <View style={{ marginTop: 50,  justifyContent: 'center',
                    alignItems: 'center'  }}>
                    <Image source={telegramLogo}/>
                </View>
                <View style={stylesTelegram.SectionStyle}>
                    <TextInput
                        style={stylesTelegram.inputStyle}
                        placeholder="Enter Phone Number" //dummy@abc.com
                        placeholderTextColor="black"
                        autoCapitalize="none"
                        returnKeyType="next"
                        blurOnSubmit={false}
                        onChangeText={
                            mobileNo => setMobileNo(mobileNo)
                        }
                    />
                </View>
                <TouchableOpacity
                    style={stylesTelegram.buttonStyle}
                    activeOpacity={0.5}
                    onPress={() => {
                        postSetMobileNo(mobileNo);
                    }}>
                    <Text style={stylesTelegram.buttonTextStyle}>Register</Text>
                </TouchableOpacity>
            </View>    
            {(isLoading && screen=='registertelegram') &&  <View style={[styles.container, styles.horizontal]}>
                <ActivityIndicator />
            </View>}            
        </ScrollView>}

        {screen == 'entercode' && 
        <ScrollView>
            <View style={stylesTelegram.mainBody}>
                <View style={{ marginTop: 50,  justifyContent: 'center',
                    alignItems: 'center'  }}>
                    <Image source={telegramLogo}/>
                </View>
                <View style={stylesTelegram.SectionStyle}>
                    <TextInput
                        style={stylesTelegram.inputStyle}
                        placeholder="Enter Telegram OTP" //dummy@abc.com
                        placeholderTextColor="black"
                        autoCapitalize="none"
                        returnKeyType="next"
                        blurOnSubmit={false}
                        onChangeText={TelegramCode => setTelegramCode(TelegramCode)}
                    />
                </View>
                <TouchableOpacity
                    style={stylesTelegram.buttonStyle}
                    activeOpacity={0.5}
                    onPress={() => {
                        setScreen('conversations');
                        postSetLoginCodeTelegram();
                        telegramPush();
                    }}>
                    <Text style={stylesTelegram.buttonTextStyle}>Send Code</Text>
                </TouchableOpacity>
            </View>    
            {(isLoading && screen=='entercode') &&  <View style={[styles.container, styles.horizontal]}>
                <ActivityIndicator />
            </View>}            
        </ScrollView>}

        {screen == 'conversationstelegram' && 
        <ScrollView 
            refreshControl={
            <RefreshControl 
                refreshing={refreshing} 
                onRefresh={() => {
                    onRefresh("Refreshing");
                    getTelegramConverstations();
                }}
            />
        }> 
            <View style={stylesChatlist.wrapper}>
                    {telegramConversations.map((l, index) => (
                    <TouchableHighlight
                        underlayColor='#f0f0f0'
                        style={{ borderRadius: 20 }}
                        onPress={() =>{
                            setTelegramCurrentChatId(l.userId);
                            setTelegramCurrentAccessHash(l.access_hash);
                            setScreen('telegram-chat');
                            getTelegramMessage(l.userId,l.access_hash);
                        }
                    }>
                        <View style={stylesChatlist.lead}>
                            <View style={stylesChatlist.infoNew}>
                                <Avatar.Text size={48} label={l.first_name.substring(0,1).toUpperCase()} style={stylesChatlist.avatarItemT} />
                                <View style={stylesChatlist.chatLabel}>
                                    { l.last_name === undefined &&
                                        <Text  style={stylesChatlist.chatLabelText}>{l.first_name}</Text>
                                    }
                                    { l.last_name != undefined &&
                                        <Text  style={stylesChatlist.chatLabelText}>{l.first_name + " " +  l.last_name}</Text>
                                    }   
                                </View>
                                <View style={stylesChatlist.chatIconContainer}>
                                    <Image source={telegramIcon}/>
                                </View>                                
                            </View>
                        </View>
                    </TouchableHighlight>))}
            </View>
        </ScrollView>}
        
        {screen == 'telegram-chat' && 
        <KeyboardAvoidingView style={styles.fullHeight} behavior="padding">
                <View style={stylesChatlist.infoNew}>
                    <Ionicons
                        name="md-arrow-back"
                        style={stylesChatlist.back_button}
                        onPress={() => {
                            setScreen('conversationstelegram');
                            getTelegramConverstations();
                        }}
                    />
                </View>
                <GiftedChat styles={stylesChatlist.GiftedChat}
                    messages={telegramMessages}
                    onSend={messages => {
                        console.log('Sending',messages[0]);
                        postSendMessage(messages[0].text);
                    }}
                    user={selectedTelegramUser}
                    alwaysShowSend
                    renderSend={this.renderSend}
                />
        </KeyboardAvoidingView>}

        {screen == 'chat' && 
        <KeyboardAvoidingView style={styles.fullHeight} behavior="padding">
            {selectedUser && <>
                <View style={stylesChatlist.infoNew}>
                    <Ionicons
                        name="md-arrow-back"
                        style={stylesChatlist.back_button}
                        onPress={() => {
                            setScreen('conversations');
                            getConversations();
                        }}
                    />
                    <Text style={stylesChatlist.headerChatText}>{('Replying as ' + selectedUser.name)}</Text>
                </View>
                <GiftedChat styles={stylesChatlist.GiftedChat}
                    messages={messages}
                    onSend={messages => {
                        console.log('Sending',messages[0]);
                        var m = {
                            target: ChatBoard.chat.target,
                            text: messages[0].text,
                            userId: '',
                            name: '',            
                        }
                        if(ChatBoard.chat.chatId){
                            m.chatId = ChatBoard.chat.chatId;
                        }
                        console.log(ChatBoard.chat, m);
                        ChatBoard.service.post('/bean/create/pulseMessage', m, (pm)=>{
                            console.log('Message created',pm);
                            if(pm.success){
                                if(pm.result && pm.result.hasOwnProperty('chatId')){
                                    ChatBoard.chat.chatId = pm.result.chatId;
                                }
                                getMessages();
                            }
                        });
                    }}
                    user={selectedUser}
                    alwaysShowSend
                    renderSend={this.renderSend}          
                />
            </>}
        </KeyboardAvoidingView>}
    </Provider>   
    )
};