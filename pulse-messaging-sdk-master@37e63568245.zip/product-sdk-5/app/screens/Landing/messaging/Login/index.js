import React, { useState } from 'react';

//Import all required component
import {
  StyleSheet,
  TextInput,
  View,
  Text,
  ScrollView,
  Keyboard,
  TouchableOpacity,
  KeyboardAvoidingView,
  Image
} from 'react-native';
import MCLogo from '../assets/multichat-logo.png';

var user={
    username: 'pluklibertyrajal@yahoo.com',
    email: 'pluklibertyrajal@yahoo.com',
    firstname: 'Lex Luger',
    lastname: 'Basilio',
    gender: 'M',
    birthDate: '11/17/1993',
    mobileNo: '',
    photo: '',
    agentRefCode: '',
    covidFlag: '',
    policyPulse: '',
    address: ''
};

var service = {
    authResult: {},
    getUser: () => {
        return service.authResult.result;
    },
    getDeviceID: () => {
        return '';
    },
    authenticate: (userName, cb) => {
        service.post(
            '/login',
            {
              username: userName,
              password: "na2K8aYNjRX+zsJ3V/phoQ==",
            },
            (p) => {
             
              if (p.success) {
                service.authResult = p;
              }
              cb(p);
            }
        );  
    },
    post: (path, data, cb) => {
        let formData = new FormData();
        let json = JSON.stringify(data);
        formData.append('data', json);
        if (service.getUser() && service.getUser().token)
          formData.append('token', service.getUser().token);
        if (service.getUser() && service.getUser().clientid)
          formData.append('clientid', service.getUser().clientid);
        if (service.getDeviceID()) formData.append('deviceid', service.getDeviceID());
  
        let headers = {
          'cache-control': 'no-cache',
          'no-store': 'true',
          'must-revalidate': 'true',
          'pre-check': '0',
          'post-check': '0',
          'max-age': '0',
          's-maxage': '0',
          Expires: '0',
          Pragma: 'no-cache'
        };
  
        let payload = {
          method: 'POST',
          headers: headers,
          body: formData
        };
  
        fetch("https://chat.gallium.space"+ path, payload)
          .then((response) => response.json())
          .then((result) => {
            cb(result);
          })
          .catch((error) => {
            cb({ success: false, message: '', result: error });
          });
      }
};


const LoginScreen = props => {
  let [userEmail, setUserEmail] = useState('');
  let [errortext, setErrortext] = useState('');

  const handleSubmitPress = () => {
    setErrortext('');
    if (!userEmail) {
      alert('Please enter your email');
      return;
    }
    user.email = userEmail;
    service.authenticate(userEmail, p=>{
        if(p.success){
            alert('Login Success');
            props.onLogin(  service.getUser().token, service.getUser().username);
        }
        else{
            alert('Login Failed');
        }
    });
  };

  return (
    <View style={styles.mainBody}>
      <ScrollView keyboardShouldPersistTaps="handled">
      <View style={{ marginTop: 100,  justifyContent: 'center',
                alignItems: 'center'  }}>
      <Image source={MCLogo} />
      </View>
        <View>
          <KeyboardAvoidingView enabled>
            <View style={styles.SectionStyle}>
              <TextInput
                style={styles.inputStyle}
                onChangeText={UserEmail => setUserEmail(UserEmail)}
                placeholder="Email" //dummy@abc.com
                placeholderTextColor="black"
                autoCapitalize="none"
                keyboardType="email-address"
                ref={ref => {
                  this._emailinput = ref;
                }}
                returnKeyType="next"
                blurOnSubmit={false}
              />
            </View>
            {errortext != '' ? (
              <Text style={styles.errorTextStyle}> {errortext} </Text>
            ) : null}
            <TouchableOpacity
              style={styles.buttonStyle}
              activeOpacity={0.5}
              onPress={handleSubmitPress}>
              <Text style={styles.buttonTextStyle}>LOGIN</Text>
            </TouchableOpacity>
          </KeyboardAvoidingView>
        </View>
      </ScrollView>
    </View>
  );
};
export default LoginScreen;

const styles = StyleSheet.create({
  mainBody: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ffffff',
  },
  SectionStyle: {
    flexDirection: 'row',
    height: 40,
    marginTop: 20,
    marginLeft: 35,
    marginRight: 35,
    margin: 10,
  },
  buttonStyle: {
    backgroundColor: '#ed1b2e',
    borderWidth: 0,
    color: '#FFFFFF',
    borderColor: '#ed1b2e',
    height: 40,
    alignItems: 'center',
    borderRadius: 30,
    marginLeft: 35,
    marginRight: 35,
    marginTop: 20,
    marginBottom: 20,
  },
  buttonTextStyle: {
    color: '#FFFFFF',
    paddingVertical: 10,
    fontSize: 16,
  },
  inputStyle: {
    flex: 1,
    color: 'black',
    paddingLeft: 15,
    paddingRight: 15,
    borderWidth: 1,
    borderRadius: 30,
    borderTopEndRadius:30,
    borderColor: 'black'
  },
  registerTextStyle: {
    color: '#FFFFFF',
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 14,
  },
  errorTextStyle: {
    color: 'red',
    textAlign: 'center',
    fontSize: 14,
  },
});