import React from 'react';
import {
    StatusBar
} from 'react-native';
import Splash from './Splash';
import Dashboard from './Dashboard';
import Login from './Login';
export default class Pulso extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            loading: true,
            screen: "login",
            token:"",
            id:""
        }
    }

    componentDidMount() {
        setTimeout(() => this.setState({
            loading: false
        }), 3000);
    }

    render() {
        let { loading,screen,token,id } = this.state;

        return <>
            <StatusBar backgroundColor="#ed1b2e" />
            {loading && <Splash />}
            {(!loading && screen=='login') &&  <Login onLogin={(token, id)=>{  
                    this.setState({
                    screen: 'chat',
                    token: token,
                    id:id
                    })
                }} />}
            {screen=='chat' && <Dashboard tokenAccess={token} userId={id}/>}  
        </>
    }
}