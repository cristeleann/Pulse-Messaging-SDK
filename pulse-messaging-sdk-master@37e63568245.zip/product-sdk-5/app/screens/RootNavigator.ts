import { createStackNavigator } from 'react-navigation';

import * as routes from '../routes';

import LandingScreen from './Landing/LandingScreen';

const RootNavigator = createStackNavigator(
  {
    [routes.Landing]: LandingScreen
  },
  { initialRouteName: routes.Landing, headerMode: 'none' }
);

export default RootNavigator;
