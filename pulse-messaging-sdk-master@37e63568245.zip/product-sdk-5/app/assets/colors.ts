export const red = '#ED1B2E';
export const darkRed = '#CA1626';
export const blue = '#3F9AB9';
export const lightBlue = 'rgba(63, 154, 185, 0.05)';

export const white = '#FFFFFF';
export const lightGrey = '#F7F7F7';
export const grey = '#D3DADD';
export const darkGrey = '#68737A';
export const black = '#333333';
