export const chevronLeft = require('./icon-chevronLeft.png');
export const chevronRight = require('./icon-chevronRight.png');
export const chevronRightLarge = require('./icon-chevronRightLarge.png');
export const tickSmall = require('./icon-tickSmall.png');
export const expand = require('./icon-expand.png');
export const collapse = require('./icon-collapse.png');
export const close = require('./icon-close.png');
