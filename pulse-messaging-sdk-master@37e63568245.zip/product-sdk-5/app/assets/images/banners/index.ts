export const landing = require('./banner-landing.png');
