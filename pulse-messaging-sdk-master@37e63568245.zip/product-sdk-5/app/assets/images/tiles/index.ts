export const makeClaim = require('./tile-makeClaim.png');
export const myPolicy = require('./tile-myPolicy.png');
export const reviewClaim = require('./tile-reviewClaim.png');
export const rewards = require('./tile-rewards.png');
