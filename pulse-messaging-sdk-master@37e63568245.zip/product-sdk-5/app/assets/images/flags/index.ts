export const au = require('./flag-au.png');
export const cn = require('./flag-cn.png');
export const eu = require('./flag-eu.png');
export const sg = require('./flag-sg.png');
