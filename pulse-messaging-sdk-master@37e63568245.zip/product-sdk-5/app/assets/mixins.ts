import { openSans } from './fonts';

const fontWeightFamilies = {
  thin: openSans.light,
  normal: openSans.regular,
  semiBold: openSans.semiBold,
  bold: openSans.bold
};

type FontFamilyOptions = { weight?: keyof typeof fontWeightFamilies };

export const getFontFamilyStyle = ({ weight }: FontFamilyOptions): string =>
  weight ? `font-family: "${fontWeightFamilies[weight]}";` : '';
