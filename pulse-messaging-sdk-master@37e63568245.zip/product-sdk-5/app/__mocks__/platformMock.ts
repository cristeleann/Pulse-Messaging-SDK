import { Platform } from 'react-native';

const defaultOS = Platform.OS;

export const resetOS = (): void => {
  Platform.OS = defaultOS;
};

export const setOS = (newOS: 'ios' | 'android' | 'windows' | 'macos' | 'web'): void => {
  Platform.OS = newOS;
};
