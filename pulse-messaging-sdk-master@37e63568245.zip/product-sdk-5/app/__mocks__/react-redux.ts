const dispatch = jest.fn();

// @ts-ignore
module.exports = {
  ...jest.requireActual('react-redux'),
  useDispatch: jest.fn(() => dispatch),
  useSelector: jest.fn()
};
