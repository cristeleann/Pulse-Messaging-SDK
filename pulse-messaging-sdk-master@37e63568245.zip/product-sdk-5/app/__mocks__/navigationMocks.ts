import { StackNavigationProp } from '../types/navigation';

export const stackNavigationMock: StackNavigationProp = {
  addListener: jest.fn(),
  closeDrawer: jest.fn(),
  dangerouslyGetParent: jest.fn(),
  dismiss: jest.fn(),
  dispatch: jest.fn(),
  isFocused: jest.fn(),
  openDrawer: jest.fn(),
  replace: jest.fn(),
  setParams: jest.fn(),
  state: {},
  toggleDrawer: jest.fn(),
  navigate: jest.fn(),
  push: jest.fn(),
  goBack: jest.fn(),
  pop: jest.fn(),
  popToTop: jest.fn(),
  getParam: jest.fn()
};
