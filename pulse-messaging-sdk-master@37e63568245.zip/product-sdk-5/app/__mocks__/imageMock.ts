// @ts-ignore
module.exports = 1;
