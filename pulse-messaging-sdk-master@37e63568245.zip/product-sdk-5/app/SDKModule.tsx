import React from 'react';
import { Provider } from 'react-redux';

import RootNavigator from './screens/RootNavigator';
import store from './store';

const SDKModule: React.FC = () => {
  return (
    <Provider store={store}>
      <RootNavigator />
    </Provider>
  );
};

export default SDKModule;
