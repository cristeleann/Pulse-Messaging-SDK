import React from 'react';
import { TextInputProps } from 'react-native';

import { grey } from '../../assets/colors';

import { Container, StyledInput } from './InputStyles';

interface Props extends TextInputProps {
  value: string;
  prefix?: React.ReactNode;
  containerTestID?: string;
}

const Input: React.FC<Props> = ({ value, prefix, containerTestID, ...inputProps }) => {
  return (
    <Container filled={Boolean(value)} testID={containerTestID}>
      {prefix}
      <StyledInput placeholderTextColor={grey} value={value} {...inputProps} />
    </Container>
  );
};

export default Input;
