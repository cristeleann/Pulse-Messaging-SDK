import React from 'react';
import { render, RenderAPI } from 'react-native-testing-library';

import Text from '../Text';

import Input from './Input';

const renderInput = (props = {}): RenderAPI => render(<Input value="" testID="Input" {...props} />);

describe('Input', () => {
  it('should call onChangeText with the value when pressed', () => {
    const onChangeText = jest.fn();

    const { getByTestId } = renderInput({
      onChangeText
    });

    getByTestId('Input').props.onChangeText('test value');

    expect(onChangeText).toHaveBeenCalledTimes(1);
    expect(onChangeText).toHaveBeenCalledWith('test value');
  });

  it('should render a prefix when provided', () => {
    const { getByText } = renderInput({
      prefix: <Text>Test text</Text>
    });

    expect(getByText('Test text')).toBeTruthy();
  });

  it('should have the expected default child props', () => {
    const { getByTestId } = renderInput({
      containerTestID: 'TestInputContainer'
    });

    const containerProps = getByTestId('TestInputContainer').props;

    expect(containerProps.filled).toBe(false);
  });

  it('should set the expected child props', () => {
    const { getByTestId } = renderInput({
      containerTestID: 'TestInputContainer',
      value: 'test value'
    });

    const containerProps = getByTestId('TestInputContainer').props;

    expect(containerProps.filled).toBe(true);
  });
});
