import styled from 'styled-components/native';

import { blue, grey, white } from '../../assets/colors';
import { getFontFamilyStyle } from '../../assets/mixins';
import { isIOS } from '../../utils/platform';

interface StyledProps {
  filled?: boolean;
}

/* istanbul ignore next: can't dynamically change this in tests */
const padding = isIOS() ? '16px 20px' : '8px 20px';

const getBorderColor = ({ filled }: StyledProps): string => (filled ? blue : grey);

export const Container = styled.View`
  flex-direction: row;
  width: 100%;
  border-radius: 10px;
  align-items: center;
  padding: ${padding};
  background-color: ${white};
  border: 1px solid ${getBorderColor};
`;

const inputFontFamilyStyle = getFontFamilyStyle({ weight: 'normal' });

export const StyledInput = styled.TextInput`
  width: 100%;
  text-align-vertical: top;
  font-size: 25px;
  flex-shrink: 1;
  flex-basis: 100%;
  ${inputFontFamilyStyle}
`;
