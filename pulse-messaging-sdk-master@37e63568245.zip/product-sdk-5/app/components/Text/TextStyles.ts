import styled from 'styled-components/native';

import * as colors from '../../assets/colors';
import { getFontFamilyStyle } from '../../assets/mixins';

export type TextColor = keyof typeof colors;
export type TextWeight = 'thin' | 'normal' | 'semiBold' | 'bold';

interface StyledProps {
  marginTop?: number;
  marginBottom?: number;
  size?: number;
  color?: TextColor;
  weight?: TextWeight;
}

const getMarginTopStyle = ({ marginTop }: StyledProps): string =>
  marginTop !== undefined ? `margin-top: ${marginTop}px;` : '';
const getMarginBottomStyle = ({ marginBottom }: StyledProps): string =>
  marginBottom !== undefined ? `margin-bottom: ${marginBottom}px;` : '';

export const StyledView = styled.View`
  ${getMarginTopStyle}
  ${getMarginBottomStyle}
`;

const getFontSizeStyle = ({ size }: StyledProps): string => (size ? `font-size: ${size}px;` : '');
const getColorStyle = ({ color }: StyledProps): string => (color ? `color: ${colors[color]};` : '');

export const StyledText = styled.Text<StyledProps>`
  ${getFontSizeStyle}
  ${getFontFamilyStyle}
  ${getColorStyle}
`;
