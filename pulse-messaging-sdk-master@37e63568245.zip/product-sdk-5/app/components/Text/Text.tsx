import React from 'react';
import { TextProps } from 'react-native';

import { StyledText, StyledView, TextColor, TextWeight } from './TextStyles';

interface Props extends TextProps {
  children: React.ReactNode;
  size?: number;
  weight?: TextWeight;
  color?: TextColor;
  marginTop?: number;
  marginBottom?: number;
}

const Text: React.FC<Props> = ({ marginTop, marginBottom, ...textProps }) => {
  if (marginTop !== undefined || marginBottom !== undefined) {
    return (
      <StyledView marginTop={marginTop} marginBottom={marginBottom}>
        <StyledText {...textProps} />
      </StyledView>
    );
  }

  return <StyledText {...textProps} />;
};

export default Text;
