import React from 'react';
import { render } from 'react-native-testing-library';

import Text from './Text';

describe('Text', () => {
  it('should render as expected', () => {
    const { toJSON } = render(<Text>Test text</Text>);

    expect(toJSON()).toMatchSnapshot();
  });

  it('should render with the expected styles when they are set', () => {
    const { toJSON } = render(
      <Text color="red" size={30} weight="bold">
        Test text
      </Text>
    );

    expect(toJSON()).toMatchSnapshot();
  });

  it('should render inside a View when marginTop is set', () => {
    const { toJSON } = render(<Text marginTop={10}>Test text</Text>);

    expect(toJSON()).toMatchSnapshot();
  });

  it('should render inside a View when marginBottom is set', () => {
    const { toJSON } = render(<Text marginBottom={20}>Test text</Text>);

    expect(toJSON()).toMatchSnapshot();
  });
});
