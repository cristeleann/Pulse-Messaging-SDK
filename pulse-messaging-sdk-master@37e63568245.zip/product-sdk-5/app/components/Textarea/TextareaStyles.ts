import styled from 'styled-components/native';

import { blue, grey, white } from '../../assets/colors';
import { getFontFamilyStyle } from '../../assets/mixins';
import { isIOS } from '../../utils/platform';

interface StyledProps {
  filled?: boolean;
}

/* istanbul ignore next: can't dynamically change this in tests */
const padding = isIOS() ? '12px 20px 16px' : '10px 18px 0px';

const getBorderColor = ({ filled }: StyledProps): string => (filled ? blue : grey);

export const Container = styled.View`
  flex-direction: row;
  width: 100%;
  border-radius: 10px;
  align-items: flex-start;
  padding: ${padding};
  background-color: ${white};
  border: 1px solid ${getBorderColor};
`;

const textareaFontFamilyStyle = getFontFamilyStyle({ weight: 'normal' });

export const StyledTextarea = styled.TextInput`
  width: 100%;
  text-align-vertical: top;
  font-size: 15px;
  flex: 1 1;
  ${textareaFontFamilyStyle}
`;
