import React from 'react';
import { render, RenderAPI } from 'react-native-testing-library';

import Textarea from './Textarea';

const renderTextarea = (props = {}): RenderAPI => render(<Textarea value="" testID="Textarea" {...props} />);

describe('Textarea', () => {
  it('should call onChangeText with the value when pressed', () => {
    const onChangeText = jest.fn();

    const { getByTestId } = renderTextarea({
      onChangeText
    });

    getByTestId('Textarea').props.onChangeText('test value');

    expect(onChangeText).toHaveBeenCalledTimes(1);
    expect(onChangeText).toHaveBeenCalledWith('test value');
  });

  it('should have the expected default child props', () => {
    const { getByTestId } = renderTextarea({
      containerTestID: 'TestTextareaContainer'
    });

    const containerProps = getByTestId('TestTextareaContainer').props;

    expect(containerProps.filled).toBe(false);
  });

  it('should set the expected child props', () => {
    const { getByTestId } = renderTextarea({
      containerTestID: 'TestTextareaContainer',
      value: 'test value'
    });

    const containerProps = getByTestId('TestTextareaContainer').props;

    expect(containerProps.filled).toBe(true);
  });
});
