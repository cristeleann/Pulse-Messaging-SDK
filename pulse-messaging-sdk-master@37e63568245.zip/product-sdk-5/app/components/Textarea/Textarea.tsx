import React from 'react';
import { TextInputProps } from 'react-native';

import { grey } from '../../assets/colors';

import { Container, StyledTextarea } from './TextareaStyles';

interface Props extends TextInputProps {
  value: string;
  containerTestID?: string;
}

const Textarea: React.FC<Props> = ({ value, containerTestID, ...inputProps }) => {
  return (
    <Container filled={Boolean(value)} testID={containerTestID}>
      <StyledTextarea multiline placeholderTextColor={grey} value={value} {...inputProps} />
    </Container>
  );
};

export default Textarea;
