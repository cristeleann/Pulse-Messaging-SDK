import { setOS, resetOS } from '../__mocks__/platformMock';

import { isIOS } from './platform';

describe('platform', () => {
  describe('isIOS', () => {
    afterEach(resetOS);

    it('should return false when the Platform is Android', () => {
      setOS('android');

      expect(isIOS()).toBe(false);
    });

    it('should return false when the Platform is iOS', () => {
      setOS('ios');

      expect(isIOS()).toBe(true);
    });
  });
});
