import { createStore, combineReducers } from 'redux';

import SDKReducer from './reducers/SDKReducer';

const reducers = {
  SDK: SDKReducer
};

const rootReducer = combineReducers(reducers);

const store = createStore(rootReducer);

export default store;

export type RootState = ReturnType<typeof rootReducer>;
