module.exports = {
  preset: 'react-native',
  setupFiles: ['jest-prop-type-error'],
  setupFilesAfterEnv: ['@testing-library/jest-native/extend-expect'],
  clearMocks: true,
  coverageDirectory: 'coverage',
  coverageThreshold: {
    global: {
      branches: 80,
      functions: 80,
      lines: 80,
      statements: 80
    }
  },
  moduleNameMapper: {
    '\\.(eot|otf|webp|svg|ttf|woff|woff2|mp4|webm|wav|mp3|m4a|aac|oga)$': '<rootDir>/app/__mocks__/fileMock.ts',
    '\\.(jpg|jpeg|png|gif)$': '<rootDir>/app/__mocks__/imageMock.ts'
  },
  moduleFileExtensions: ['ts', 'tsx', 'js', 'jsx', 'json']
};
