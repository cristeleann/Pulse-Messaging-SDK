# PULSE Messaging React-Native Library

This is the React-Native collection of capabilities for Interoprability and Messaging


### Installation

```
cd product-sdk-5
yarn install

cd product-sdk-app-5
yarn install

react-native link

cd ios

pod install

```

Open a 3 terminals from the product-sdk-app-5 directory

1. For synchronizing code from the SDK to the App Testbed

```shell script
npx nodemon \
    --watch "../product-sdk-5/index.js" \
    --watch "../product-sdk-5/app" \
    --exec "yarn cp:sdk-template" \
    -e "ts,tsx,js,jsx,png,jpg,json"
```

2. Start Metro

```
yarn start
```


## Running

iOS it is prefered to open the CleanRn59.xcworkspace and run the build there.

You may also try

```
yarn ios
```


```
yarn android
```
