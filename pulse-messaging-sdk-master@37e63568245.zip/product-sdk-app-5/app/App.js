import React from 'react';
import { View } from 'react-native';

import RootNavigator from "./RootNavigator";

export default function App() {
  return (
    <View style={{ flex: 1 }}>
      <RootNavigator />
    </View>
  );
}
