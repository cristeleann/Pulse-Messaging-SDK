import React from 'react';
import { View, Image, Text } from 'react-native';
import { SDKModule } from 'product-sdk-5';

export default function HomeScreen({ navigation }) {
  return (
    <View style={{ flex: 1 }}>
      <SDKModule />
    </View>
  );
}
