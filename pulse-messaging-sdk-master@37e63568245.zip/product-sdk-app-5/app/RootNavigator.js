import { createStackNavigator } from "react-navigation";

import HomeScreen from "./screens/HomeScreen";

const RootNavigator = createStackNavigator(
  {
    Home: HomeScreen
  },
  { initialRouteName: 'Home', headerMode: 'none' }
);

export default RootNavigator;
