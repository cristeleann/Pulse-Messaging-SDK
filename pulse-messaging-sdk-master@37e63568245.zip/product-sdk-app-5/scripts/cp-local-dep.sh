#!/usr/bin/env bash

set -e

# This copies over an NPM module from a local directory
# because symlinks work poorly with RN 59

BASE_DIR=$(pwd)
PACKAGE_NAME=$1
DEPENDENCY_DIR="${BASE_DIR}/node_modules/${PACKAGE_NAME}"

if [ -z "$PACKAGE_NAME" ]; then
  echo "Usage: sh ./scripts/cp-local-dep.sh [local dependency name]"
  exit
fi

if [[ -L "$DEPENDENCY_DIR" ]]; then
  echo "${PACKAGE_NAME} is a symlink, removing it & copying the whole project over"

  rm -rf "$DEPENDENCY_DIR"
  cp -r "../${PACKAGE_NAME}" "${BASE_DIR}/node_modules"
  rm -rf "${DEPENDENCY_DIR}/node_modules"
elif [[ -d "$DEPENDENCY_DIR" ]]; then
  echo "${PACKAGE_NAME} is a normal directory, only copying the source & package.json files"

  rm -rf "${DEPENDENCY_DIR}/app"
  cp -r "../${PACKAGE_NAME}/app" "$DEPENDENCY_DIR"
  cp "../${PACKAGE_NAME}/package.json" "$DEPENDENCY_DIR"
  cp "../${PACKAGE_NAME}/index.js" "$DEPENDENCY_DIR"
else
  echo "${PACKAGE_NAME} doesn't exist at all in node_modules, copying the whole project over"

  cp -r "../${PACKAGE_NAME}" "${BASE_DIR}/node_modules"
  rm -rf "${DEPENDENCY_DIR}/node_modules"
fi

echo "installing ${PACKAGE_NAME} production dependencies (skipping dev dependencies)"
cd "$DEPENDENCY_DIR" && yarn install --production

## EXPERIMENTAL - only enable these lines if you know what you're doing!
# echo "hoisting child dependencies into app node_modules"
# cp -r "$DEPENDENCY_DIR"/node_modules/* "${BASE_DIR}/node_modules"

echo "${PACKAGE_NAME} successfully set up!"
