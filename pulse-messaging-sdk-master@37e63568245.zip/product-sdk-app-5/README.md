# React Native 0.59 example app

This can be used to test running other React Native modules inside it.

The dependency versions in this app have been intentionally set to match those
in One Pulse. This means this example app can be used as a lightweight testbed
for modules that are targeting integration into One Pulse.

## Installation/Setup

Run `yarn install` to install dependencies.

## Building the app as a standalone APK

Run `yarn android`. The APK will end up in: `build/release/app-release.apk`.

## Linking local dependencies (LOCAL DEV ONLY)

Use this script to copy an entire local dependency over: `yarn cp:sdk-template`.

You can copy/modify this script inside package.json if you need to link
another local dependency. If you do add new dependencies, don't forget to add
a new entry into the regex inside metro.config.js.

You could optionally also automate the copying process as you make changes to
the local dependency via nodemon:

```shell script
npx nodemon \
    --watch "../product-sdk-5/index.js" \
    --watch "../product-sdk-5/app" \
    --exec "yarn cp:sdk-template" \
    -e "ts,tsx,js,jsx,png,jpg,json"
```

### Alternative linking technique (NOT RECOMMENDED)

This is documented here as a last resort in case the above method fails.

You can attempt to locally symlink dependencies, but these have issues with
React Native 0.59 (e.g., images may not work in android). If you do this
technique, you will need to uncomment out the code block at the bottom of the
metro.config.js file, then add the dependency link inside package.json:

```
"dependencies": {
  "my-local-dependency": "link:../my-local-dependency",
```

Then run `yarn install` and it'll link automatically.

## Running in a simulator

Assuming you have a simulator already running, start by running:
`yarn start:clean` in one terminal tab.

Then open another terminal tab and run either `yarn android` or `yarn ios`
depending on which you want to run.
